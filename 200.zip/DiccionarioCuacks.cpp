#include <iostream>
#include "DiccionarioCuacks.h"

DiccionarioCuacs::DiccionarioCuacs() {}