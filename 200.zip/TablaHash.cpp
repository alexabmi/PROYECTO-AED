#include "TablaHash.h"
#include <iostream>
#include <functional>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

TablaHash::TablaHash() {
    tam = 100;
    nElem = 0;
    tabla = new list<Par>[tam];
}

TablaHash::~TablaHash() {
    delete[] tabla;
}

int TablaHash::hash(string clave) {
    std::hash<string> hashFn;
    return hashFn(clave) % tam;
}

void TablaHash::insertar(Cuack nuevo) {
    if (nElem > tam * 0.7)
        reestructurar();

    string clave = nuevo.getUsuario();
    int indice = hash(clave);

    auto it = tabla[indice].begin();
    while (it != tabla[indice].end() && it->usuario != clave)
        ++it;

    if (it != tabla[indice].end()) {
        auto it2 = it->listaCuacks.begin();
        while (it2 != it->listaCuacks.end() && !it2->es_anterior(nuevo))
            ++it2;
        it->listaCuacks.insert(it2, nuevo);
    } else {
        Par p;
        p.usuario = clave;
        p.listaCuacks.push_back(nuevo);
        tabla[indice].push_back(p);
    }

    nElem++;
}

void TablaHash::consultar(string nombre) {
    int indice = hash(nombre);

    auto it = tabla[indice].begin();
    while (it != tabla[indice].end() && it->usuario != nombre)
        ++it;

    int total = 0;
    cout << "follow " << nombre << endl;

    if (it != tabla[indice].end()) {
        int i = 1;
        for (Cuack nuevo : it->listaCuacks) {
            cout << i << ". ";
            nuevo.mostrarCuac();
            i++;
            total++;
        }
    }

    cout << "Total: " << total << " cuac" << endl;
}


void TablaHash::reestructurar() {
    int nuevoTam = tam * 2 + 1;
    list<Par>* nuevaTabla = new list<Par>[nuevoTam];
    std::hash<string> hashFn;

    for (int i = 0; i < tam; i++) {
        for (Par p : tabla[i]) {
            int nuevoIndice = hashFn(p.usuario) % nuevoTam;
            nuevaTabla[nuevoIndice].push_back(p);
        }
    }

    delete[] tabla;
    tabla = nuevaTabla;
    tam = nuevoTam;
}

void TablaHash::us_por_cubeta() {
    for (int i = 0; i < tam; i++) {
        int numUsuarios = tabla[i].size();
        cout << "Cubeta " << i << ": " << numUsuarios << " usuarios" << endl;
    }
}
