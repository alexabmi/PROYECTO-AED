#ifndef TABLAHASH_H
#define TABLAHASH_H

#include "cuack.h"
#include <string>
#include <list>

struct Par {
    std::string usuario;
    std::list<Cuack> listaCuacks;
};

class TablaHash {
    private:
        std::list<Par>* tabla;
        int tam;
        int nElem;
        int hash(std::string clave);
        void reestructurar();
    public:
        TablaHash();
        ~TablaHash();
        void insertar(Cuack nuevo);
        void consultar(std::string nombre);
        void us_por_cubeta();
        int numElem(void) { return nElem; }
};

#endif
