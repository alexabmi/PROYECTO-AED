#ifndef FECHA_H
#define FECHA_H
#include <string>

class Fecha {
private:
    int dia, mes, anio, hora, min, seg;

public:
    Fecha();
    Fecha(int d, int m, int anyo, int h, int mins, int s);

    bool guardarFecha();
    void mostrarFecha();
    static int compararFechas(Fecha f1, Fecha f2);
    int getDia();
    int getMes();
    int getAnio();
    bool operator<(Fecha otra);
    std::string getHora();
    std::string getMinutos();
    std::string getSegundos();
    bool operator>(const Fecha &otra) const {
        if (anio != otra.anio) return anio > otra.anio;
        if (mes != otra.mes) return mes > otra.mes;
        if (dia != otra.dia) return dia > otra.dia;
        if (hora != otra.hora) return hora > otra.hora;
        if (min != otra.min) return min > otra.min;
        return seg > otra.seg;
    }
};

#endif