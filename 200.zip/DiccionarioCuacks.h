#ifndef DICCIONARIOCUACS_H
#define DICCIONARIOCUACS_H

#include "fecha.h"
#include "cuack.h"
#include "TablaHash.h"
#include <string>

class DiccionarioCuacs {
   private:
     TablaHash tabla;
   public:
     DiccionarioCuacs ();
     void insertar (Cuack nuevo) {  tabla.insertar(nuevo); }
     void follow (std::string nombre) { tabla.consultar(nombre); }
     int numElem () { return tabla.numElem(); }
};

#endif