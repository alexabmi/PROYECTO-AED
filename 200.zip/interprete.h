#ifndef INTERPRETE_H
#define INTERPRETE_H

#include <string>

void Interprete(std::string comando);
void procesar_mcuac();
void procesar_pcuac();
void procesar_follow();

#endif
